import paho.mqtt.client as mqtt
import time, json, threading, logging, ssl
import sparkplug_b_pb2
import configparser
import argparse
from confluent_kafka import Producer
#python main.py --propertiesfile C:/Users/Projjwal/PycharmProjects/HiveMQ.properties

# Declaring Global Veriables
run = True
broker =""
port = ""
topic = ""
username = ""
password = ""
myGroupId = ""
myGroupName = ""
myDeviceName = ""
namespace = ""
kafkaProducerServer = ""
kafkaHost = ""
kafkaPort = ""
kafkaTopicName = ""
keepalive=""
kafkaHostPortCombibe = ""

def Create_connections(config):
    # Reads list of clients to connect
    listClients = str(config.get("GeneralProperties", "clients"))
    clients = listClients.split(":")

    # Create connection for each client, staty connected and starts subscribing
    for clientcred in clients:
        client_id = clientcred.split(",")[2]
        client = mqtt.Client(client_id=client_id)
        client.on_log = on_log
        client.on_connect = on_connect
        subscribe(client,client_id,config)
        client.on_disconnect = on_disconnect
        print("connecting to broker")

        # client.tls_set("CXXXXX.crt", tls_version=ssl.PROTOCOL_TLSv1_2)
        # client.tls_insecure_set(True)
        username = clientcred.split(",")[0]
        password = clientcred.split(",")[1]
        client.username_pw_set(username, password)
        client.loop_start()
        client.connect(broker,port,keepalive)
        #print("Loop pass ")


def on_log(client, userdata, level, buf):
    #print("message:" + str(buf))
    #print("userdata:" + str(userdata))
    pass


def on_connect(client, userdata, flags, rc):
    print("Connected with result code:" + str(rc))
    client.subscribe(topic)

def on_disconnect(client, userdata, rc):
    client.loop_stop(force=False)
    if rc != 0:
        print("Unexpected disconnection.")
    else:
        print("Disconnected")

def on_publish(client, userdata, mid):
    #print("mid: " + str(mid) + '\n')
    pass


def subscribe(client: mqtt,client_id,config):
    def on_message(client, userdata, msg):
        tokens = msg.topic.split("/")

        if tokens[0] == namespace and tokens[1] == myGroupName and tokens[2] == myGroupId and tokens[4] == client_id:
            inboundPayload = sparkplug_b_pb2.Payload()
            inboundPayload.ParseFromString(msg.payload)
            data = {}

            for metric in inboundPayload.metrics:

                if len(str(metric.properties)) > 5:

                    if config.get("FileInputSchema", str(metric.properties.keys[0]))=="String":
                        data[str(metric.properties.keys[0])] = str(metric.properties.values[0].string_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Int":
                        data[str(metric.properties.keys[0])] = int(metric.properties.values[0].int_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Float":
                        data[str(metric.properties.keys[0])] = float(metric.properties.values[0].float_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Boolean":
                        data[str(metric.properties.keys[0])] = bool(metric.properties.values[0].boolean_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Double":
                        data[str(metric.properties.keys[0])] = float(metric.properties.values[0].double_value)

                json_data = json.dumps(data)
            #print(str(json_data))

            #Sending Message to Kafka Topic
            producer = Producer({kafkaProducerServer: kafkaHostPortCombibe})
            producer.produce(kafkaTopicName, json_data)
            producer.flush()

        else:
            #print("Searching For Correct GroupID..")
            pass

    client.subscribe(topic)
    client.on_message = on_message


if __name__ == '__main__':
    # Take User input for properties file path
    parser = argparse.ArgumentParser()
    parser.add_argument("--propertiesfile", required=True)
    arguments = vars(parser.parse_args())

    # Load Properties File
    config = configparser.RawConfigParser()
    config.read(str(arguments["propertiesfile"]))

    # Initializing Global Variables
    broker = str(config.get("GeneralProperties", "broker"))
    port = int(config.get("GeneralProperties", "port"))
    keepalive = int(config.get("GeneralProperties", "keepalive"))
    topic = str(config.get("GeneralProperties", "topic"))
    myGroupId = str(config.get("GeneralProperties", "myGroupId"))
    myGroupName = str(config.get("GeneralProperties", "myGroupName"))
    namespace = str(config.get("GeneralProperties", "namespace"))
    kafkaProducerServer = str(config.get("GeneralProperties", "kafkaProducerServer"))
    kafkaHost = str(config.get("GeneralProperties", "kafkaHost"))
    kafkaPort = str(config.get("GeneralProperties", "kafkaPort"))
    kafkaTopicName = str(config.get("GeneralProperties", "kafkaTopicName"))
    kafkaHostPortCombibe = kafkaHost + ":" + kafkaPort

    mqtt.Client.connected_flag = False
    no_threads = threading.active_count()
    print("current threads =", no_threads)

    #Start creating connection for each client
    Create_connections(config)
    while run:
        pass
