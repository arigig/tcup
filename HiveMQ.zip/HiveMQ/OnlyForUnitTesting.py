# python3.6
from paho.mqtt import client as mqtt_client
import sparkplug_b_pb2
import argparse
import configparser
import json
from confluent_kafka import Producer
#python main.py --propertiesfile C:/Users/Projjwal/PycharmProjects/HiveMQ.properties

# HiveMQ Configuration
broker = ""
port = ""
topic = ""
#client_id = ""
username = ""
password = ""
myGroupId = ""
myGroupName = ""
#myDeviceName = ""
namespace = ""
myNodeName = ""

#Kafka Configuration
kafkaProducerServer=""
kafkaHost=""
kafkaPort=""
kafkaTopicName=""
kafkaHostPortCombibe=""

class DemoSubscriber:
    Next_Server = 0
    Rebirth = 1
    Reboot = 2
    Dataset = 3
    Node_Metric0 = 4
    Node_Metric1 = 5
    Node_Metric2 = 6
    Node_Metric3 = 7
    Device_Metric0 = 8
    Device_Metric1 = 9
    Device_Metric2 = 10
    Device_Metric3 = 11
    My_Custom_Motor = 12

def connect_mqtt(config) -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    #client = mqtt_client.Client(client_id)
    client = mqtt_client.Client()
    #client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client,config):
    def on_message(client, userdata, msg):
        tokens = msg.topic.split("/")

        if tokens[0] == namespace and tokens[1] == myGroupName and tokens[2] == myGroupId:
        #if tokens[0] == namespace and tokens[1] == myGroupName and tokens[2] == myGroupId and tokens[3] == myNodeName:
            inboundPayload = sparkplug_b_pb2.Payload()
            inboundPayload.ParseFromString(msg.payload)
            #print(inboundPayload)
            data = {}

            for metric in inboundPayload.metrics:
                # print("metric.alias::"+str(metric.alias))
                # print("metric.timestamp::"+str(metric.timestamp))
                # print("metric.datatype::"+str(metric.datatype))

                if len(str(metric.properties)) > 5:

                    if config.get("FileInputSchema", str(metric.properties.keys[0]))=="String":
                        data[str(metric.properties.keys[0])] = str(metric.properties.values[0].string_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Int":
                        data[str(metric.properties.keys[0])] = int(metric.properties.values[0].int_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Float":
                        data[str(metric.properties.keys[0])] = float(metric.properties.values[0].float_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Boolean":
                        data[str(metric.properties.keys[0])] = bool(metric.properties.values[0].boolean_value)

                    elif config.get("FileInputSchema", str(metric.properties.keys[0]))=="Double":
                        data[str(metric.properties.keys[0])] = float(metric.properties.values[0].double_value)

                json_data = json.dumps(data)

            # Sending Message to Kafka Topic
            producer = Producer({kafkaProducerServer: kafkaHostPortCombibe})
            producer.produce(kafkaTopicName, json_data)
            producer.flush()

        else:
            print("Searching For Correct GroupID..")

    client.subscribe(topic)
    client.on_message = on_message


def run(config):
    client = connect_mqtt(config)
    subscribe(client,config)
    client.loop_forever()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--propertiesfile", required=True)
    arguments = vars(parser.parse_args())
    # Load Properties File
    config = configparser.RawConfigParser()
    config.read(str(arguments["propertiesfile"]))

    # Initializing Global Parameters
    broker = str(config.get("GeneralProperties", "broker"))
    port = int(config.get("GeneralProperties", "port"))
    topic = str(config.get("GeneralProperties", "topic"))
    username = str(config.get("GeneralProperties", "username"))
    password = str(config.get("GeneralProperties", "password"))
    myGroupId = str(config.get("GeneralProperties", "myGroupId"))
    myGroupName = str(config.get("GeneralProperties", "myGroupName"))
    #myDeviceName = str(config.get("GeneralProperties", "myDeviceName"))
    namespace = str(config.get("GeneralProperties", "namespace"))
    myNodeName = str(config.get("GeneralProperties", "myNodeName"))
    kafkaProducerServer = str(config.get("GeneralProperties", "kafkaProducerServer"))
    kafkaHost = str(config.get("GeneralProperties", "kafkaHost"))
    kafkaPort = str(config.get("GeneralProperties", "kafkaPort"))
    kafkaTopicName = str(config.get("GeneralProperties", "kafkaTopicName"))
    kafkaHostPortCombibe=kafkaHost+":"+kafkaPort

    # broker = "localhost"
    # port = 1883
    # topic = "spBv1.0/#"
    # username = "device01"
    # password = "device01"
    # myGroupId = "DDATA"
    # myGroupName = "Sparkplug B Devices"
    # myDeviceName = "device01"
    # namespace = "spBv1.0"
    # nodes="Python Edge Node 1"
    # myNodeName = "Python Edge Node 1"
    # kafkaProducerServer = "bootstrap.servers"
    # kafkaHost = "localhost"
    # kafkaPort = 9092
    # kafkaTopicName = "first_topic"
    # kafkaHostPortCombibe = kafkaHost + ":" + kafkaPort

    # Calling Main method to start execution
    run(config)