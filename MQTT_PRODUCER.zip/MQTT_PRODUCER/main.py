import sys
import paho.mqtt.client as mqtt
import sparkplug_b as sparkplug
import json
from sparkplug_b import *
import argparse
import configparser
# python main.py --inputfile C:/Users/Projjwal/PycharmProjects/Test_Data.txt --propertiesfile C:/Users/Projjwal/PycharmProjects/Producer.properties

serverUrl = ""
serverPort=""
keepAlive=""
namespace=""
myGroupId = ""
myNodeName = ""
myDeviceName = ""
myUsername = ""
myPassword = ""

class AliasMap:
    Next_Server = 0
    Rebirth = 1
    Reboot = 2
    Dataset = 3
    Node_Metric0 = 4
    Node_Metric1 = 5
    Node_Metric2 = 6
    Node_Metric3 = 7
    Device_Metric0 = 8
    Device_Metric1 = 9
    Device_Metric2 = 10
    Device_Metric3 = 11
    My_Custom_Motor = 12


######################################################################
# The callback for when the client receives a CONNACK response from the server.
######################################################################
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected with result code " + str(rc))
    else:
        print("Failed to connect with result code " + str(rc))
        sys.exit()

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe(namespace + myGroupId + "/NCMD/" + myNodeName + "/#")
    client.subscribe(namespace + myGroupId + "/DCMD/" + myNodeName + "/#")

######################################################################
# The callback for when a PUBLISH message is received from the server.
######################################################################
def on_message(client, userdata, msg):
    print("Inside On_Message")
    tokens = msg.topic.split("/")

    if tokens[0] == namespace1 and tokens[1] == myGroupId and (tokens[2] == "NCMD" or tokens[2] == "DCMD") and tokens[
        3] == myNodeName:
        inboundPayload = sparkplug_b_pb2.Payload()
        inboundPayload.ParseFromString(msg.payload)
        for metric in inboundPayload.metrics:
            if metric.name == "Node Control/Next Server" or metric.alias == AliasMap.Next_Server:
                print("'Node Control/Next Server' is not implemented in this example")
            elif metric.name == "Node Control/Rebirth" or metric.alias == AliasMap.Rebirth:
                publishBirth()
            elif metric.name == "Node Control/Reboot" or metric.alias == AliasMap.Reboot:
                publishBirth()
            else:
                print("Command execution strategy not decided: " + metric.name)
    else:
        print("Unknown command...")

    print("Done publishing")

######################################################################
# Publish the BIRTH certificates
######################################################################
def publishBirth():
    publishNodeBirth()
    publishDeviceBirth()

######################################################################
# Publish the NBIRTH certificate
######################################################################
def publishNodeBirth():
    print("Publishing Node Birth")

    # Create the node birth payload
    payload = sparkplug.getNodeBirthPayload()

    # Set up the Node Controls
    addMetric(payload, "Node Control/Next Server", AliasMap.Next_Server, MetricDataType.Boolean, False)
    addMetric(payload, "Node Control/Rebirth", AliasMap.Rebirth, MetricDataType.Boolean, False)
    addMetric(payload, "Node Control/Reboot", AliasMap.Reboot, MetricDataType.Boolean, False)

    # Publish the node birth certificate
    byteArray = bytearray(payload.SerializeToString())
    client.publish(namespace + myGroupId + "/NBIRTH/" + myNodeName, byteArray, serverQOS, False)

######################################################################
# Publish the DBIRTH certificate
######################################################################
def publishDeviceBirth():
    print("Publishing Device Birth")

    # Get the payload
    payload = sparkplug.getDeviceBirthPayload()

    # Add some device metrics
    addMetric(payload, "input/Device Metric0", AliasMap.Device_Metric0, MetricDataType.String, "hello device")

    # Publish the initial data with the Device BIRTH certificate
    totalByteArray = bytearray(payload.SerializeToString())
    client.publish(namespace + myGroupId + "/DBIRTH/" + myNodeName + "/" + myDeviceName, totalByteArray, serverQOS, False)

if __name__ == '__main__':
    print("Starting main application")
    # Take User input for properties file path
    parser = argparse.ArgumentParser()
    parser.add_argument("--inputfile", required=True)
    parser.add_argument("--propertiesfile", required=True)
    arguments = vars(parser.parse_args())

    # Load Properties File
    config = configparser.RawConfigParser()
    config.read(str(arguments["propertiesfile"]))

    # Initialize Parameters
    serverUrl = str(config.get("GeneralProperties","serverUrl"))
    serverPort= str(config.get("GeneralProperties","serverPort"))
    keepAlive= str(config.get("GeneralProperties","keepAlive"))
    serverQOS= int(config.get("GeneralProperties","serverQOS"))
    namespace = str(config.get("GeneralProperties","namespace"))+"/"
    namespace1 = str(config.get("GeneralProperties", "namespace"))
    myGroupId = str(config.get("GeneralProperties","myGroupId"))
    myNodeName = str(config.get("GeneralProperties","myNodeName"))
    myDeviceName = str(config.get("GeneralProperties","myDeviceName"))
    myUsername = str(config.get("GeneralProperties","myUsername"))
    myPassword = str(config.get("GeneralProperties","myPassword"))
    sleepTimer=int(config.get("GeneralProperties","sleepTimer"))

    # Create the node death payload
    deathPayload = sparkplug.getNodeDeathPayload()

    # Start of main program - Set up the MQTT client connection
    #client = mqtt.Client(client_id=myDeviceName)
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.username_pw_set(myUsername, myPassword)
    client.connect("localhost", 1883, 60)

    deathByteArray = bytearray(deathPayload.SerializeToString())

    client.will_set(namespace + myGroupId + "/NDEATH/" + myNodeName, deathByteArray, 0, False)
    client.connect(serverUrl, int(serverPort), int(keepAlive))

    # Short delay to allow connect callback to occur
    time.sleep(.1)
    client.loop()

    # Publish the birth certificates
    publishBirth()

    # Read line by line from a input file after some time internal to produce device input
    input_file = open(str(arguments["inputfile"]), 'r')
    Lines = input_file.readlines()
    for line in Lines:

        # Setting-up some time interval before reading the next line. Configurabe through properties file
        time.sleep(sleepTimer)
        print("sending next data...."+str(line.strip()))

        # convert string to  object
        json_object = json.loads(str(line.strip()))

        # Initiate PayLoad
        payload = sparkplug.getDdataPayload()

        for keys in json_object:
            if keys in config.options("FileInputSchema"):
                if config.get("FileInputSchema", str(keys))=="String":
                    metric = addMetric(payload, None, AliasMap.Device_Metric1, MetricDataType.String, myDeviceName)
                    metric.properties.keys.extend([str(keys)])
                    propertyValue = metric.properties.values.add()
                    propertyValue.type = ParameterDataType.String
                    propertyValue.string_value = json_object[str(keys)]
                elif config.get("FileInputSchema", str(keys))=="Int":
                    metric = addMetric(payload, None, AliasMap.Device_Metric1, MetricDataType.String, myDeviceName)
                    metric.properties.keys.extend([str(keys)])
                    propertyValue = metric.properties.values.add()
                    propertyValue.type = ParameterDataType.Int64
                    propertyValue.int_value = int(json_object[str(keys)])
                elif config.get("FileInputSchema", str(keys))=="Float":
                    metric = addMetric(payload, None, AliasMap.Device_Metric1, MetricDataType.String, myDeviceName)
                    metric.properties.keys.extend([str(keys)])
                    propertyValue = metric.properties.values.add()
                    propertyValue.type = ParameterDataType.Float
                    propertyValue.float_value = float(json_object[str(keys)])
                elif config.get("FileInputSchema", str(keys))=="Boolean":
                    metric = addMetric(payload, None, AliasMap.Device_Metric1, MetricDataType.String, myDeviceName)
                    metric.properties.keys.extend([str(keys)])
                    propertyValue = metric.properties.values.add()
                    propertyValue.type = ParameterDataType.Boolean
                    propertyValue.boolean_value = bool(json_object[str(keys)])
                elif config.get("FileInputSchema", str(keys))=="Double":
                    metric = addMetric(payload, None, AliasMap.Device_Metric1, MetricDataType.String, myDeviceName)
                    metric.properties.keys.extend([str(keys)])
                    propertyValue = metric.properties.values.add()
                    propertyValue.type = ParameterDataType.Double
                    propertyValue.double_value = float(json_object[str(keys)])

            else:
                print("Some unknown keys are present in file lines. exiting from code")
                sys.exit()

        #Publish a message data
        byteArray = bytearray(payload.SerializeToString())
        client.publish(namespace + myGroupId + "/DDATA/" + myNodeName + "/" + myDeviceName, byteArray, serverQOS, False)

