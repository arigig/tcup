from confluent_kafka import Consumer, KafkaException
import sys
import argparse
# python main.py --kafkagroup python-consumer --kafkahost localhost --kafkaport 9092 --kafkatopics first_topic --kafkasessionout 12000

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument("--kafkagroup", required=True)
    parser.add_argument("--kafkahost", required=True)
    parser.add_argument("--kafkaport", required=True)
    parser.add_argument("--kafkatopics", required=True)
    parser.add_argument("--kafkasessionout", required=True)
    arguments = vars(parser.parse_args())

    # Initializing Global Parameters
    group = str(arguments["kafkagroup"])
    host = str(arguments["kafkahost"])
    port = str(arguments["kafkaport"])
    topics = [str(arguments["kafkatopics"])]
    broker = host+":"+port
    kafkasessionout = int(arguments["kafkasessionout"])
    # topics = ["first_topic"]

    conf = {'bootstrap.servers': broker, 'group.id': group, 'session.timeout.ms': kafkasessionout,
            'auto.offset.reset': 'earliest', 'enable.auto.offset.store': False}

    # Create logger for consumer (logs will be emitted when poll() is called)
    # logger = logging.getLogger('consumer')
    # logger.setLevel(logging.DEBUG)
    # handler = logging.StreamHandler()
    # handler.setFormatter(logging.Formatter('%(asctime)-15s %(levelname)-8s %(message)s'))
    # logger.addHandler(handler)

    # Create Consumer instance
    # c = Consumer(conf, logger=logger)
    c = Consumer(conf)

    def print_assignment(consumer, partitions):
        print('Assignment:', partitions)

    # Subscribe to topics
    #c.subscribe(topics, on_assign=print_assignment)
    c.subscribe(topics, on_assign=print_assignment)

    # Read messages from Kafka, print to stdout
    csv_content = []
    try:
        while True:
            msg = c.poll(timeout=1.0)
            if msg is None:
                continue
            if msg.error():
                raise KafkaException(msg.error())
            else:
                c.store_offsets(msg)
                print(msg.value())
    except KeyboardInterrupt:
        sys.stderr.write('%% Aborted by user\n')
    finally:
        c.close()